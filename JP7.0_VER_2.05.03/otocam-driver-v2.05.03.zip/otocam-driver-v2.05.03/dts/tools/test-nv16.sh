if [ $# -eq 0 ]; then
	v4l2-ctl -d /dev/video0 --set-fmt-video=pixelformat=NV16 --stream-mmap --stream-count=1 --stream-to=nv16-video0.raw
else
	v4l2-ctl -d /dev/video$1 --set-fmt-video=pixelformat=NV16 --stream-mmap --stream-count=3 --stream-to=nv16-video$1.raw --verbose
fi
