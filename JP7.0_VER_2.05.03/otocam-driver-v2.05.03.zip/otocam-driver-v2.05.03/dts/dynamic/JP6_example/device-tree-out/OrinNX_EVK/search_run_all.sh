for f in *.dtbo; do
    set-dtb-to-dts.sh $f;
	mv device-tree.dts $f.dts;
done