if [ $# -eq 0 ]; then
	v4l2-ctl -d /dev/video0 --set-fmt-video=width=3840,height=2160,pixelformat=UYVY --stream-mmap --verbose
else
	if [ $1 -eq 0 ]; then
		v4l2-ctl -d /dev/video0 --set-fmt-video=width=3840,height=2160,pixelformat=UYVY --stream-mmap --stream-count=3 --stream-to=nv16-video0-$1.raw --verbose
	else
		v4l2-ctl -d /dev/video0 --set-fmt-video=width=512,height=288,pixelformat=UYVY --stream-mmap --stream-count=3 --stream-to=nv16-video0-$1.raw --verbose
	fi
fi
