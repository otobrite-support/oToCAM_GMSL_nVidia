#!/bin/bash

for ((j=0;j<5;j++)); do
	for ((i=0;i<16;i++)); do
		[ -e /dev/video$i ] || continue
		gst-launch-1.0 -e v4l2src device=/dev/video$i \
			! fpsdisplaysink &
		#sleep 0.5
	done
	sleep 5
	killall gst-launch-1.0
	sleep 5
done
