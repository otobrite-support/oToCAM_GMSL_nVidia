#define I2C_BUS	i2c@3180000	// cam_i2c
//#define I2C_BUS	cam_i2cmux
#if 0
#define I2C_MUX	//tca9546@70
//#define I2C_MUX_TCA9546
#define I2C_BUS_CAM0	/bus@0/I2C_BUS/i2c@0
#define I2C_BUS_CAM1	/bus@0/I2C_BUS/i2c@0
#define I2C_BUS_CAM2	/bus@0/I2C_BUS/i2c@1
#define I2C_BUS_CAM3	/bus@0/I2C_BUS/i2c@1
#define I2C_BUS_CAM4	/bus@0/I2C_BUS/i2c@1
#define I2C_BUS_CAM5	/bus@0/I2C_BUS/i2c@1
#define I2C_BUS_CAM6	/bus@0/I2C_BUS/i2c@1
#define I2C_BUS_CAM7	/bus@0/I2C_BUS/i2c@1
#else
#define I2C_BUS_CAM0	/bus@0/I2C_BUS
#define I2C_BUS_CAM1	/bus@0/I2C_BUS
#define I2C_BUS_CAM2	/bus@0/I2C_BUS
#define I2C_BUS_CAM3	/bus@0/I2C_BUS
#define I2C_BUS_CAM4	/bus@0/I2C_BUS
#define I2C_BUS_CAM5	/bus@0/I2C_BUS
#define I2C_BUS_CAM6	/bus@0/I2C_BUS
#define I2C_BUS_CAM7	/bus@0/I2C_BUS
#endif

#define CSI_NUM_CHANS	1 //support max cams
#define CSI_NUM_PORTS	1 //Number of aggregated ports
#define CSI_PORT_LANES	2 //4lane or 2lane
#define CSI_SERDES_TYPE 3 //0:m9296, 1:m96712, 2:m96724, 3:m96714
#if (CSI_SERDES_TYPE==0)
#define CSI_SERDES	2 // max cams connected to a dser
#elif (CSI_SERDES_TYPE==1)
#define CSI_SERDES	4 // max cams connected to a dser
#elif (CSI_SERDES_TYPE==2)
#define CSI_SERDES	4 // max cams connected to a dser
#elif (CSI_SERDES_TYPE==3)
#define CSI_SERDES	1 // max cams connected to a dser
#else
#define CSI_SERDES	2 // max cams connected to a dser
#endif
#define CSI_SERDES_GMSL

#define CAM_MODE	imx390isp //isx021, isx031, imx390isp, imx490isp, imx728isp, ar0823isp

