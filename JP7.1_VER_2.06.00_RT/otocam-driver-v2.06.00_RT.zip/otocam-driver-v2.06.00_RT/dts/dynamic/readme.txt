# oToCAM Sample DTS

## Features:
1. I2C bus: mux or not
2. CSI_NUM_CHANS : support max cams
3. CSI_NUM_PORTS : Number of aggregated ports
4. CSI_PORT_LANES : 4lane or 2lane
5. CSI_SERDES_TYPE : 0:m9296, 1:m96712, 2:m96724, 3:m96714
6. CAM_MODE : isx021, isx031, imx390isp, imx490isp, imx728isp, ar0823isp

## Files Structure:
+ t23x/	## JP6.x
  ├── tegra234-camera-config.h
  ├── tegra234-p3737-0000+p3701-0004-nv-otocam.dts
  ├── tegra234-p3737-camera-imx390-overlay-otocam.dts
  ├── tegra234-p3737-camera-modules-otocam.dtsi
  ├── tegra234-p3768-0000+p3767-0000-nv-otocam.dts
  ├── tegra234-p3767-camera-imx390-overlay-otocam.dts
  ├── tegra234-p3768-camera-modules-otocam.dtsi
  └── etc.
+ otocam/	## JP6.x
  ├── tegra234-camera-imx390-i2c.dtsi	
  ├── tegra234-camera-imx390-a00.dtsi	
  ├── tegra194-camera-all-mode.dtsi
  ├── tegra194-camera-imx390isp-mode.dtsi
  ├── tegra194-camera-imx490isp-mode.dtsi
  ├── tegra194-camera-imx728isp-mode.dtsi
  ├── tegra194-camera-ar0823isp-mode.dtsi
  ├── tegra194-camera-isx021-mode.dtsi
  ├── tegra194-camera-isx031-mode.dtsi
  └── etc.
+ agx-orin/	## JP5.x
+ nx-orin/	## JP5.x
+ otocam/	## JP5.x
  ├── tegra194-p2822-0000-camera-imx390-a00.dtsi	## cam.0-3
  ├── tegra194-p2822-0000-camera-imx390-a00-4.dtsi	## cam.4-7
  ├── tegra194-camera-imx390-a00.dtsi	## cam.0-3
  ├── tegra194-camera-imx390-a00-4.dtsi	## cam.4-7
  └── etc.
