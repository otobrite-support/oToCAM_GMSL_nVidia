support for otocam260isp/otocam264isp/otocam271isp

1. check bus id (default 2)
i2cdetect -l 
2. check sensor(isp) remap addr
i2cdetect -r -y 2 (default 10~17)
3. *.sh $(bus id) $(isp remap addr)
