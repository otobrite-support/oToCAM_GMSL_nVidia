sleep 1
oToAdapter_addr=("0x27" "0x4e")
for addr in "${oToAdapter_addr[@]}"; do
    data=0
    data=$(sudo i2ctransfer -y -f 2 w2@$addr 0x4 0xb1 r1)
    if [[ "$data" == "0x40" ]]; then
        if [[ "$addr" == "0x27" ]]; then
            echo internal fsync start in dser1.
        else
            echo internal fsync start in dser2.
        fi
        sudo i2ctransfer -y -f 2 w3@$addr 0x4 0xaf 0xcf
        sudo i2ctransfer -y -f 2 w3@$addr 0x4 0xa0 0x04
        sudo i2ctransfer -y -f 2 w3@$addr 0x4 0xaf 0xc0
    fi
done