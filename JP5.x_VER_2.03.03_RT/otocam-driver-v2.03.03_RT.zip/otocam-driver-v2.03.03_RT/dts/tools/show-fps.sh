#!/bin/bash
for ((i=0;i<8;i++)); do
	[ -e /dev/video$i ] || continue
	echo "video$i"
	v4l2-ctl -d /dev/video$i --set-fmt-video=pixelformat=NV16 --stream-mmap &
	#sleep 0.5
done
