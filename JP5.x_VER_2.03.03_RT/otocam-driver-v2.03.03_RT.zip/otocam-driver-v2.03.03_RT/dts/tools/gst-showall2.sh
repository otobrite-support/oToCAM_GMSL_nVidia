#!/bin/bash
#set -x

declare -a gst_options
if [ $# -eq 0 ]; then
    for ((i=0;i<16;i++)); do
        [ -e /dev/video$i ] || continue
        if [ -z "$1" ]; then
            gst_options+=("v4l2src device=/dev/video$i !fpsdisplaysink sync=0")
        else
            gst_options+=("v4l2src device=/dev/video$i ! nvvidconv ! nvv4l2h265enc ! h265parse ! matroskamux ! multifilesink next-file=4 max-file-size=10000000 max-files=3 post-messages=true location=video$i-h265_%02d.mp4")
        fi
    done
    #echo "${gst_options[@]}"
    gst-launch-1.0 -e ${gst_options[@]}
else
    if [ $1 -eq 0 ]; then
        gst-launch-1.0 -e v4l2src device=/dev/video0 ! 'video/x-raw,format=UYVY,width=3840,height=2160' !fpsdisplaysink
    else
        gst-launch-1.0 -e v4l2src device=/dev/video0 ! 'video/x-raw,format=UYVY,width=512,height=288' !fpsdisplaysink
    fi
fi
