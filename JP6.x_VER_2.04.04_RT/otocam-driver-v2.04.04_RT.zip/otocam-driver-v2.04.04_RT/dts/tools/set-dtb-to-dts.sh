dtc -I dtb -O dts -o device-tree.dts $1
