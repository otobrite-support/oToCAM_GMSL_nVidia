sudo rmmod oToCAM
sudo rmmod oToSerDes
