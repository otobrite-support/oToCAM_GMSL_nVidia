#512K limit
if [ $# = 0 ];then
    echo enter video node
    exit
fi
script -o 512000 -c "v4l2-ctl -d /dev/video$1 --set-fmt-video=pixelformat=NV16 --stream-mmap --verbose" video$1.txt

