if [ -z "$2" ];then
	dtc -I dts -O dtb -o $1 device-tree.dts
else
	dtc -I dts -O dtb -o $1 $2
fi
