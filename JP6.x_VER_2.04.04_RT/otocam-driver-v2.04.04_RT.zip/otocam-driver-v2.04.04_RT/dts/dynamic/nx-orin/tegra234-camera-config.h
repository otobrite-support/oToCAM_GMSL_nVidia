//#define I2C_BUS	/i2c@3180000
#define I2C_BUS	/cam_i2cmux
#if 1
#define I2C_MUX
#define I2C_BUS_CAM0	I2C_BUS/i2c@0
#define I2C_BUS_CAM1	I2C_BUS/i2c@0
#define I2C_BUS_CAM2	I2C_BUS/i2c@1
#define I2C_BUS_CAM3	I2C_BUS/i2c@1
#else
//#define I2C_BUS	/cam_i2cmux/i2c@0
#define I2C_BUS_CAM0	I2C_BUS
#define I2C_BUS_CAM1	I2C_BUS
#define I2C_BUS_CAM2	I2C_BUS
#define I2C_BUS_CAM3	I2C_BUS
#endif

#define CSI_NUM_CHANS	4
#define CSI_NUM_PORTS	2
#define CSI_PORT_LANES	4
#define CSI_SERDES	2	// Ser:Des
#define CSI_SERDES_GMSL

#define CAM_MODE	imx390isp
