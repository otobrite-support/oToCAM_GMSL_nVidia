#!/bin/sh

FOLDER=( \
    "agx_orin_9296" \
    "nx_orin_96712" 
)
DTS_NAME=( \
    "tegra234-p3737-camera-modules-otocam-overlay.dts" \
    "tegra234-p3768-camera-modules-otocam-overlay.dts" 
)
DTBO_NAME=( \
    "tegra234-p3737-camera-modules-otocam-overlay.dtbo" \
    "tegra234-p3768-camera-modules-otocam-overlay.dtbo" 
)

mkdir -p dts_out
len=${#FOLDER[@]}
for (( i=0; i<len; i++ )); do
    echo ${FOLDER[$i]}/${DTS_NAME[$i]}
    echo ${DTBO_NAME[$i]}
    cpp -nostdinc -I. -undef -x assembler-with-cpp ${FOLDER[$i]}/${DTS_NAME[$i]} > temp.dts
    if [[ "$?" == "1" ]]; then
        rm temp.dts
        break
    fi
    dtc -@ -O dtb -o ${DTBO_NAME[$i]} temp.dts > /dev/null 2>&1
    rm temp.dts
    mv ${DTBO_NAME[$i]} dts_out
done
