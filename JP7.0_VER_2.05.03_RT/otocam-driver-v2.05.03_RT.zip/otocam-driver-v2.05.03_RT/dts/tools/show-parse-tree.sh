dtc -I fs -O dts /proc/device-tree -o device-tree-running.dts
