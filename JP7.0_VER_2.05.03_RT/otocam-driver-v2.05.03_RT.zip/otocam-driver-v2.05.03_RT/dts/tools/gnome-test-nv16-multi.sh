#!/bin/bash
#set -x

if [ $# -eq 0 ]; then
    for ((i=0;i<16;i++)); do
        [ -e /dev/video$i ] || continue
        #gnome-terminal --title="video$i" -- v4l2-ctl -d /dev/video$i --set-fmt-video=pixelformat=NV16 --stream-mmap --verbose
        gnome-terminal --title="video$i" -- sh ./gnome-test-nv16.sh $i
    done
fi