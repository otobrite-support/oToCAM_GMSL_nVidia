#!/bin/bash
#set -x
link=("A" "B" "C" "D")
link_lock=("0x0 0x1a" "0x0 0xa" "0x0 0xb" "0x0 0xc")
video_lock=("0x1 0xdc" "0x1 0xfc" "0x2 0x1c" "0x2 0x3c")
bit_loss=("0x0 0x35" "0x0 0x36" "0x0 0x37" "0x0 0x38")
oToAdapter_addr=("0x27" "0x4e")
for addr in "${oToAdapter_addr[@]}"; do
    result=$(sudo i2ctransfer -y -f 2 w2@$addr 0x0 0xd r1 2>/dev/null)
    if [[ $? -eq 0 ]]; then
        echo "$addr dser DEV_ID: $result"
        for i in "${!link_lock[@]}"; do
            val="${link_lock[$i]}"
            ret=$(sudo i2ctransfer -y -f 2 w2@$addr $val r1)
            if (( (ret & 8) != 0 )); then
                echo "link${link[$i]} is link locked."
            fi
        done
        for i in "${!video_lock[@]}"; do
            val="${video_lock[$i]}"
            ret=$(sudo i2ctransfer -y -f 2 w2@$addr $val r1)
            if (( (ret & 1) != 0 )); then
                echo "link${link[$i]} is video locked."
            fi
        done
        ret=$(sudo i2ctransfer -y -f 2 w2@$addr 0x0 0x26 r1)
        if (( (ret & 0xf) != 0 )); then
            echo "bit loss occurs."
            for i in "${!bit_loss[@]}"; do
                val="${bit_loss[$i]}"
                ret=$(sudo i2ctransfer -y -f 2 w2@$addr $val r1)
                echo "link${link[$i]} bit loss reg value $ret."
            done
        fi
        
    fi
done

#echo "bit loss"
#i2ctransfer -y -f 2 w2@0x27 0x0 0x26 r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x35 r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x36 r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x37 r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x38 r1

#echo "idle error"
#i2ctransfer -y -f 2 w2@0x27 0x0 0x2c r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x39 r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x3a r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x3b r1
#i2ctransfer -y -f 2 w2@0x27 0x0 0x3c r1