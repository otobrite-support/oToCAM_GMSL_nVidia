#512K limit
if [ $# -eq 0 ];then
    echo enter video node
    exit
fi
LOG_START=$(awk '{print $1}' /proc/uptime)
#echo $LOG_START

FILE="video$1.txt"

if [ -n "$2" ]; then
    script -o $2 -c "v4l2-ctl -d /dev/video$1 --set-fmt-video=pixelformat=NV16 --stream-mmap --verbose" $FILE
else
    script -c "v4l2-ctl -d /dev/video$1 --set-fmt-video=pixelformat=NV16 --stream-mmap --verbose" $FILE
fi

if [ -f "fsync_start" ]; then
    FIRST_TS=$(awk '/ts:/ {for(i=1;i<=NF;i++)if($i=="ts:"){v=$(i+1);gsub(/[^0-9.]/,"",v);print v;exit}}' $FILE)
    FSYNC_START=$(cat fsync_start)

    SHIFT_TS=$(echo "$FIRST_TS - $LOG_START - 0.1" | bc)
    echo $SHIFT_TS
    # 1. 取得當前系統 Uptime 作為 NEW_FSYNC_START
    NEW_FSYNC_START=$(echo "$FSYNC_START + $SHIFT_TS" | bc)
    echo $NEW_FSYNC_START    
    
    if [ "$(echo "$FIRST_TS > $NEW_FSYNC_START" | bc)" -eq 1 ]; then
        echo "FIRST_TS $FIRST_TS 比 NEW_FSYNC_START $NEW_FSYNC_START 大, 插入fsync資訊取消."
        sleep 30
        exit
    fi
    # 2. 使用 awk 尋找「小於 NEW_FSYNC_START 且最接近」的行號
    # -v 傳入外部變數，NR 是行號，NF 是欄位數
    TARGET_LINE=$(awk -v now="$NEW_FSYNC_START" '
    {
        for (i=1; i<=NF; i++) {
            if ($i == "ts:") {
                val = $(i+1)
                gsub(/[^0-9.]/, "", val) # 清理欄位中的逗號或雜質
                
                # 找尋小於現在時間，且數值最大的那一行
                if (val < now) {
                    if (max_val == "" || val > max_val) {
                        max_val = val
                        best_line = NR
                    }
                }
            }
        }
    }
    END { print best_line }' "$FILE")

    # 3. 如果找到了，就用 sed 插入
    if [ -n "$TARGET_LINE" ]; then
        echo "系統時間為 $NEW_FSYNC_START，最接近的影格在第 $TARGET_LINE 行"
        # 使用 sed 在該行下方插入新時間
        sed -i "${TARGET_LINE}a \################fsync_start" "$FILE"
    else
        echo "未能在檔案中找到符合條件的 ts: 數據"
    fi
fi
