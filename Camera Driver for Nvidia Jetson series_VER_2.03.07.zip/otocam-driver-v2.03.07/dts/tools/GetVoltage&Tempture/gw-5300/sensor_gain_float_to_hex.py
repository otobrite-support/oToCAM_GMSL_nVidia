import struct
import sys

#print(sys.argv[1])
if float(sys.argv[1]) <=65535 and float(sys.argv[1]) >= 0:
    print(struct.pack("!f", float(sys.argv[1])).hex())
else:
    print("Out of range.")
