sudo apt-cache show nvidia-jetpack
cat /etc/nv_tegra_release
cat /etc/os-release

