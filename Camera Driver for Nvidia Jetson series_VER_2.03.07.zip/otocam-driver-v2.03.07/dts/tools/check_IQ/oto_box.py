import struct
import sys

match sys.argv[1]:
    case "1": #hex to float
        hex_str = sys.argv[2]
        cleaned = hex_str.replace("0x", "").replace(" ", "")
        b = bytes.fromhex(cleaned)
        if len(b) == 4:
            val = struct.unpack("<f", b)[0]   # > = little-endian, f = 4-byte float
            print(val)
        elif len(b) > 4:
            first4 = b[:4]
            val = struct.unpack("<f", first4)[0]   # > = little-endian, f = 4-byte float
            print(val)
    case "2": #hex to string
        data = sys.argv[2]
        hex_list = [int(x, 16) for x in data.split()]
        print(''.join(chr(h) for h in hex_list if h != 0x00))
    case "3": #hex to int
        hex_str = sys.argv[2]
        cleaned = hex_str.replace("0x", "")
        b = bytes.fromhex(cleaned)
        val = int.from_bytes(b, "little")
        print(val)
    case "4": #260isp exposure time
        hex_str = sys.argv[2]
        cleaned = hex_str.replace("0x", "")
        b = bytes.fromhex(cleaned)
        val = int.from_bytes(b, "little")
        # print(val / (30 * 1798)) #second
        print(val / (30 * 1798)* 1000) #micro second
    case "5": #GdB to Glinear
        print(10 ** (float(sys.argv[2]) / 20))
    case "6": #int to hex
        print(struct.pack("!i", int(sys.argv[2])).hex())
    case "7": #float to hex
        print(struct.pack("!f", float(sys.argv[2])).hex())
    case "8": #271isp exposure time
        hex_str = sys.argv[2]
        cleaned = hex_str.replace("0x", "")
        b = bytes.fromhex(cleaned)
        val = int.from_bytes(b, "little")
        # print(val / (30 * 2400) + 2032 * 1 / (30 * 2400 * 5000)) #second
        print(val / (30 * 2400) * 1000) #micro second
    case _:  # Default case
        print("Unknown status code")