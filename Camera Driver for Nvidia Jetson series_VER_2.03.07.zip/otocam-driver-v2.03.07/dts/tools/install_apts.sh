sudo apt-get install v4l-utils
sudo apt-get install gstreamer1.0-plugins-bad