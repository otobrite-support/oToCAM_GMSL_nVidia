#define VID_RQX58G	// ADLink

#define I2C_BUS	/i2c@c240000
#define I2C_MUX	4
#define I2C_MUX_TCA9546
#define I2C_BUS_CAM0	I2C_BUS/tca9546@70/i2c@0
#define I2C_BUS_CAM1	I2C_BUS/tca9546@70/i2c@0
#define I2C_BUS_CAM2	I2C_BUS/tca9546@70/i2c@1
#define I2C_BUS_CAM3	I2C_BUS/tca9546@70/i2c@1
#define I2C_BUS_CAM4	I2C_BUS/tca9546@70/i2c@2
#define I2C_BUS_CAM5	I2C_BUS/tca9546@70/i2c@2
#define I2C_BUS_CAM6	I2C_BUS/tca9546@70/i2c@3
#define I2C_BUS_CAM7	I2C_BUS/tca9546@70/i2c@3

#define CSI_NUM_CHANS	8
#define CSI_NUM_PORTS	8
#define CSI_PORT_LANES	2
#define CSI_SERDES	2	// Ser/Des
#define CSI_SERDES_GMSL

#define CAM_MODE	imx390isp
