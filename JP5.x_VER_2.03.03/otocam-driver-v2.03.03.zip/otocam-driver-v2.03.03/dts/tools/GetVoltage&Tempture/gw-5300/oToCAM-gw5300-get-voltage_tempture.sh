function cal_checksum {
    tot=0
    for i in ${var[@]}; do
      let tot+=$i
    done
    checksum=`printf "0x%02X\n" $((tot & 0xff))`
}

function i2c_transfer {
        wb=$((${#var[@]}+1))
    if [ ${var[1]} == "0x47" ];then
        ret=`i2ctransfer -y -f $bus_id w$wb@0x$slave_addr ${var[@]} $checksum r$2`
        ret_MsgID=`echo $ret | cut -d ' ' -f4`
        ret_status=`echo $ret | cut -d ' ' -f5`
        if [ $ret_status != "0x01" ];then
            echo API command fail ret_status=$ret_status, send=${var[@]}, exit.
            exit;
        fi
    elif [ ${var[1]} == "0x51" ];then
        retry=0
        while : ; do
            ret=`i2ctransfer -y -f $bus_id w$wb@0x$slave_addr ${var[@]} $checksum r$2`
            ret_status=`echo $ret | cut -d ' ' -f9`
            
            if [ $ret_status == "0x02" ] || [ $ret_status == "0x03" ];then
                break
            else
                retry+=1
                if [ $retry -ge 5 ];then
                    echo retry fail after 5 times, force exit.
                    exit;
                fi
            fi
        done
    fi
}

function check_i2c {
    tmp=`i2ctransfer -y -f $bus_id w10@0x$slave_addr 0x33 0x47 0x03 0x00 0x00 0x00 0x01 0x00 0x80 0xcd r6`
    if [ ! "$?" -eq "0" ];then
        echo i2ctransfer fail exit
        exit
    fi
}

function voltage_temperature {
    var=(0x33 0x47 0x03 0x00 0x00 0x00 0xd0 0x00 0x80)

    cal_checksum $var

    i2c_transfer $var 6

    var=(0x33 0x51 0x07 $ret_MsgID 0x00 0x00 0xec 0x01 0x00 0x00)

    cal_checksum $var

    i2c_transfer $var 32

    voltage=`echo $ret | cut -d ' ' -f20-23`
    echo voltage=$voltage
    echo -ne `echo "${voltage//0x/\\\x}" |tr -d ' '` | hexdump -e '1/4 "%f" "\n"'

    temperature=`echo $ret | cut -d ' ' -f24-27`
    echo temperature=$temperature
    echo -ne `echo "${temperature//0x/\\\x}" |tr -d ' '` | hexdump -e '1/4 "%f" "\n"'
}

###start from here
bus_id=$1
slave_addr=$2
echo bus_id=$bus_id, sensor_addr=$slave_addr
check_i2c
voltage_temperature