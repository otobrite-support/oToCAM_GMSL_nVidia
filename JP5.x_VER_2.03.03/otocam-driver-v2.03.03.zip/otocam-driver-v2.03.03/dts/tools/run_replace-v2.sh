#!/bin/sh

# Get list of .dts files (space-separated)
dts_list=$(ls *.dts *.dtbo | sort -t. -k2 2>/dev/null)

# Check if any found
if [ -z "$dts_list" ]; then
    echo "No .dts or .dtbo files found."
    exit 1
fi

# Show indexed list
i=1
for f in $dts_list; do
    echo "$i: $f"
    i=$((i + 1))
done

# Ask user for selection
printf "Enter dts file index to apply: "
read dts_file_index

# Get selected filename
i=1
for f in $dts_list; do
    if [ "$i" = "$dts_file_index" ]; then
        selected="$f"
        break
    fi
    i=$((i + 1))
done

# Check valid selection
if [ -z "$selected" ]; then
    echo "Invalid index."
    exit 1
fi

case "$selected" in
    *.dts)
        # Generate output .dtbo filename
        dtbo_file=$(basename "$selected" .dts).dtbo
        # Compile the DTS to DTBO
        echo "compile dts to dtbo"
        dtc -I dts -O dtb -o "$dtbo_file" "$selected" 2>/dev/null|| exit 1
        # Copy to /boot
        sudo cp "$dtbo_file" /boot/ || exit 1
        # Extract base name (without extension)
        tmp2=$(basename "$selected" .dts)
        ;;
    *.dtbo)
        echo "skip compile process"
        # Copy to /boot
        sudo cp "$selected" /boot/ || exit 1
        # Extract base name (without extension)
        tmp2=$(basename "$selected" .dtbo)
        ;;
esac

# Check JetPack version
if grep -q "R36 (release), REVISION: 4.2" /etc/nv_tegra_release; then
    if [ -e "/opt/nvidia/jetson-io/Jetson/board.py.bak" ]; then
        echo "Backup exists"
    else
        echo "Backup board.py"
        sudo cp /opt/nvidia/jetson-io/Jetson/board.py /opt/nvidia/jetson-io/Jetson/board.py.bak
    fi

    sudo sed -i "s/dt.read_prop('model')/'NVIDIA Jetson Orin Nano Developer Kit'/" /opt/nvidia/jetson-io/Jetson/board.py
    sudo /opt/nvidia/jetson-io/config-by-hardware.py -n 1="Camera $tmp2"
else
	sudo /opt/nvidia/jetson-io/config-by-hardware.py -n 2="Camera $tmp2"
fi
ret=$?

if [ $ret -eq 0 ]; then
    sudo reboot
else
    echo something wrong
fi

