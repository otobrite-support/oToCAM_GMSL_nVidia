#set -x

function cal_checksum {
    tot=0
    for i in ${var[@]}; do
      let tot+=$i
    done
    checksum=`printf "0x%02X\n" $((tot & 0xff))`
}

function i2c_transfer {
        wb=$((${#var[@]}+1))
    if [ ${var[1]} == "0x47" ];then
        ret=`i2ctransfer -y -f $bus_id w$wb@0x$slave_addr ${var[@]} $checksum r$2`
        ret_MsgID=`echo $ret | cut -d ' ' -f4`
        ret_status=`echo $ret | cut -d ' ' -f5`
        if [ $ret_status != "0x01" ];then
            echo API command fail ret_status=$ret_status, send=${var[@]}, exit.
            exit;
        fi
    elif [ ${var[1]} == "0x51" ];then
        retry=0
        while : ; do
            ret=`i2ctransfer -y -f $bus_id w$wb@0x$slave_addr ${var[@]} $checksum r$2`
            ret_status=`echo $ret | cut -d ' ' -f9`
            
            if [ $ret_status == "0x02" ] || [ $ret_status == "0x03" ];then
                break
            else
                retry+=1
                if [ $retry -ge 5 ];then
                    echo retry fail after 5 times, force exit.
                    exit;
                fi
            fi
        done
    fi
}

function check_i2c {
    tmp=`i2ctransfer -y -f $bus_id w10@0x$slave_addr 0x33 0x47 0x03 0x00 0x00 0x00 0x01 0x00 0x80 0xcd r6`
    if [ ! "$?" -eq "0" ];then
        echo i2ctransfer fail exit
        exit
    fi
}

function get_ISP_live_params {
    var=(0x33 0x47 0x03 0x00 0x00 0x00 0x42 0x00 0x80)

    cal_checksum $var

    i2c_transfer $var 6
    
    var=(0x33 0x51 0x07 $ret_MsgID 0x00 0x00 0xec 0x01 0x00 0x00)

    cal_checksum $var

    i2c_transfer $var 0x1ff

    #echo $ret
    #printf '%-35s%s\n' "chunk" "`echo $ret | cut -d ' ' -f10-11`"
    #printf '%-35s%s\n' "validdatabytes" "`echo $ret | cut -d ' ' -f12-15`"
    jumper=(16 16 16 16 16 4 8 2 2 4 4 4 4 4 1 3 8 4 4 4 2 2 2 2 18 2 2 2 2 2 2 2 4 4 4 4 4 4 4 2 2 2 2 16 1 1 1 1 1 1 1 1 1 1 1 1)  #doc
    variables=("totalGain[4]" "sensorGain[4]" "ispGain[4]" "clippedEv[4]" "unclippedEv[4]" "unclippedEvAvg" "integrationLines[4]" "vts" "padAe[2]" "frameRate" "sensorAnalogGain" "sensorDigitalGain" "sensorDualConversionGain" "sensorTemperature" "numberOfSensors" "padSensor[3]" "awbGains[4]" "awbColorTemperature" "awbRGRatio" "awbBGRatio" "longMediumRatio" "mediumShortRatio" "shortVeryShortRatio" "padCombiner[2]" "colorMatrix[9]" "padCcm[2]" "ltmGain" "padLtm[2]" "blackOffsetR" "blackOffsetGR" "blackOffsetGB" "blackOffsetB" "histAvg12bLIrDsp" "histAvg12bLGrDsp" "histAvg12bLGrIspPrc" "luxEstimation" "iqsHistDarkPerc" "iqsHistBrightPerc" "iqsContrastAvg" "iqsHighContrastZoneCounter" "padIqsContrast[2]" "iqsColorOutOfBoundsZoneCounter" "iqsColorNotValidZoneCounter" "histAvg[4]" "exposureAeStatus" "exposurePostLtmStatus" "exposureOverallStatus" "exposureStatusConfidence" "contrastZoneStatus" "contrastGlobalStatus" "contrastOverallStatus" "contrastStatusConfidence" "colorStatus" "colorStatusConfidence" "frozenFrameStatus" "frozenFrameStatusConfidence")
    #jumper=(16 16 16 16 16 4 8 2 2 4 4 4 4 4 2 2 2 2 4 4 4 4 4 4 4 2 2 2 1 3 8 4 4 4 2 2 2 2 18 2 2 2 2 16 1 1 1 1 1 1 1 1 1 1 1 1) #mark
    #variables=("totalGain[4]" "sensorGain[4]" "ispGain[4]" "clippedEv[4]" "unclippedEv[4]" "unclippedEvAvg" "integrationLines[4]" "vts" "padAe[2]" "frameRate" "sensorAnalogGain" "sensorDigitalGain" "sensorDualConversionGain" "sensorTemperature" "blackOffsetR" "blackOffsetGR" "blackOffsetGB" "blackOffsetB" "histAvg12bLIrDsp" "histAvg12bLGrDsp" "histAvg12bLGrIspPrc" "luxEstimation" "iqsHistDarkPerc" "iqsHistBrightPerc" "iqsContrastAvg" "iqsHighContrastZoneCounter" "padIqsContrast[2]" "iqsColorOutOfBoundsZoneCounter" "numberOfSensors" "padSensor[3]" "awbGains[4]" "awbColorTemperature" "awbRGRatio" "awbBGRatio" "longMediumRatio" "mediumShortRatio" "shortVeryShortRatio" "padCombiner[2]" "colorMatrix[9]" "padCcm[2]" "ltmGain" "padLtm[2]"  "iqsColorNotValidZoneCounter" "histAvg[4]" "exposureAeStatus" "exposurePostLtmStatus" "exposureOverallStatus" "exposureStatusConfidence" "contrastZoneStatus" "contrastGlobalStatus" "contrastOverallStatus" "contrastStatusConfidence" "colorStatus" "colorStatusConfidence" "frozenFrameStatus" "frozenFrameStatusConfidence")
    start=16
    for i in $(seq 0 1 $((${#jumper[@]}-1))); do
        case ${variables[i]} in
            "totalGain[4]"|"sensorGain[4]"|"ispGain[4]"|"clippedEv[4]"|"unclippedEv[4]"|"unclippedEvAvg"|"sensorDigitalGain"|"sensorDualConversionGain"|"frameRate")
                set1=`echo $ret | cut -d ' ' -f$start-$((start+3))`
                set1=`echo "${set1//0x/\\\x}" |tr -d ' '`
                set1=`echo -ne $set1| hexdump -e '1/4 "%f" "\n"'`
                #printf '%-35s%s (%s)\n' ${variables[i]} "`echo $ret | cut -d ' ' -f$start-$((start+${jumper[i]}-1))`" "$set1"
                if [ ${variables[i]} == "totalGain[4]" ];then
                    Gain=$set1
                elif [ ${variables[i]} == "unclippedEv[4]" ];then
                    Exposure=$set1
                fi
                ;;
            *) # Default case (optional)
                #printf '%-35s%s\n' ${variables[i]} "`echo $ret | cut -d ' ' -f$start-$((start+${jumper[i]}-1))`"
                ;;
        esac
        start=$((start+${jumper[i]}))      
    done
    echo Gain=$(echo "scale=2; $Gain/1" | bc| awk '{printf "%.2f\n", $0}') Exposure=$(echo "scale=2; $Exposure/1000" | bc | awk '{printf "%.2f\n", $0}')ms
}

function set_max_exposure_time {
    declare -A API_Command_Message CfgParamUpdate CfgSingleParam
    max_exp_time=$(python exp_time_float_to_hex.py $1)
    #echo $max_exp_time
    #echo "0x${max_exp_time:6:2} 0x${max_exp_time:4:2} 0x${max_exp_time:2:2} 0x${max_exp_time:0:2}"
    API_Command_Message[Protocol_ID]="0x33"
    API_Command_Message[MsgType]="0x47"
    API_Command_Message[Data_Size]="0x0f 0x00 0x00 0x00"
    API_Command_Message[API_Code]="0x55"
    API_Command_Message[Chunk_Number]="0x00 0x80"
    CfgParamUpdate[specId]="0x05"
    CfgParamUpdate[reserved]="0x0"
    CfgSingleParam[paramid]="0x15 0x00"
    CfgSingleParam[numRow]="0x01 0x00"
    CfgSingleParam[rowDataSize]="0x04 0x00"
    CfgSingleParam[data]="0x${max_exp_time:6:2} 0x${max_exp_time:4:2} 0x${max_exp_time:2:2} 0x${max_exp_time:0:2}"
    
    var=(${API_Command_Message[Protocol_ID]} ${API_Command_Message[MsgType]} ${API_Command_Message[Data_Size]} ${API_Command_Message[API_Code]} ${API_Command_Message[Chunk_Number]} \
        ${CfgParamUpdate[specId]} ${CfgParamUpdate[reserved]}  \
        ${CfgSingleParam[paramid]} ${CfgSingleParam[numRow]} ${CfgSingleParam[rowDataSize]} ${CfgSingleParam[data]})

    cal_checksum $var

    i2c_transfer $var 6
}

function set_min_exposure_time {
    declare -A API_Command_Message CfgParamUpdate CfgSingleParam
    min_exposure_time=$(python exp_time_float_to_hex.py $1)
    #echo $min_exposure_time
    #echo "0x${min_exposure_time:2:2} 0x${min_exposure_time:0:2}"
    API_Command_Message[Protocol_ID]="0x33"
    API_Command_Message[MsgType]="0x47"
    API_Command_Message[Data_Size]="0x0d 0x00 0x00 0x00"
    API_Command_Message[API_Code]="0x55"
    API_Command_Message[Chunk_Number]="0x00 0x80"
    CfgParamUpdate[specId]="0x05"
    CfgParamUpdate[reserved]="0x0"
    CfgSingleParam[paramid]="0x21 0x00"
    CfgSingleParam[numRow]="0x01 0x00"
    CfgSingleParam[rowDataSize]="0x02 0x00"
    CfgSingleParam[data]="0x${min_exposure_time:2:2} 0x${min_exposure_time:0:2}"
    
    var=(${API_Command_Message[Protocol_ID]} ${API_Command_Message[MsgType]} ${API_Command_Message[Data_Size]} ${API_Command_Message[API_Code]} ${API_Command_Message[Chunk_Number]} \
        ${CfgParamUpdate[specId]} ${CfgParamUpdate[reserved]}  \
        ${CfgSingleParam[paramid]} ${CfgSingleParam[numRow]} ${CfgSingleParam[rowDataSize]} ${CfgSingleParam[data]})

    cal_checksum $var

    i2c_transfer $var 6
}

function set_max_sensor_gain {
    max_sensor_gain=$(python sensor_gain_float_to_hex.py $1)
    #echo $max_sensor_gain
    #echo "0x${max_sensor_gain:2:2} 0x${max_sensor_gain:0:2}"
    var=(0x33 0x47 0x0f 0x00 0x00 0x00 0x55 0x00 0x80 0x05 0x00 0x16 0x00 0x01 0x00 0x04 0x00 0x${max_sensor_gain:6:2} 0x${max_sensor_gain:4:2} 0x${max_sensor_gain:2:2} 0x${max_sensor_gain:0:2})

    cal_checksum $var

    i2c_transfer $var 6
}

function set_min_sensor_gain {
    min_sensor_gain=$(python sensor_gain_float_to_hex.py $1)
    #echo $min_sensor_gain
    #echo "0x${min_sensor_gain:2:2} 0x${min_sensor_gain:0:2}"
    var=(0x33 0x47 0x0f 0x00 0x00 0x00 0x55 0x00 0x80 0x05 0x00 0x31 0x00 0x01 0x00 0x04 0x00 0x${min_sensor_gain:6:2} 0x${min_sensor_gain:4:2} 0x${min_sensor_gain:2:2} 0x${min_sensor_gain:0:2})

    cal_checksum $var

    i2c_transfer $var 6
}

###start from here
bus_id=$1
slave_addr=$2
echo bus_id=$bus_id, sensor_addr=$slave_addr
check_i2c

function showMenu()
{
	echo -e "(\033[31mgw5300 test tool\033[0m) "
	echo "available operation list"
	echo "(1) get ISP live params"
	echo "(2) set_max_exposure_time"
	echo "(3) set_min_exposure_time"
	echo "(4) set_max_sensor_gain"
	echo "(5) set_min_sensor_gain"
	echo "(q) exit"
}

while : ; do
    showMenu
	read -p "Please input your choice: " selIndex
    case ${selIndex} in
        "1")
            get_ISP_live_params
            ;;
        "2")
            read -p "Please input max_exposure_time(0~4095): " selValue
			#echo $selValue
            set_max_exposure_time $selValue
            sleep 1
            get_ISP_live_params
            ;;
        "3")
            read -p "Please input min_exposure_tim(0~4095): " selValue
			#echo $selValue
            set_min_exposure_time $selValue
            sleep 1
            get_ISP_live_params
            ;;
        "4")
            read -p "Please input max_sensor_gain(0~65535): " selValue
			#echo $selValue
            set_max_sensor_gain $selValue
            sleep 1
            get_ISP_live_params
            ;;
        "5")
            read -p "Please input min_sensor_gain(0~65535): " selValue
			#echo $selValue
            set_min_sensor_gain $selValue
            sleep 1
            get_ISP_live_params
            ;;
        "q") # Default case (optional)
            echo byebye
            exit
            ;;
    esac
done
