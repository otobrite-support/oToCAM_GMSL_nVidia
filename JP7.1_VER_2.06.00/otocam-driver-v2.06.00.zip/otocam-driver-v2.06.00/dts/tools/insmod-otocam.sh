
sudo insmod ./oToSerDes.ko
sudo insmod ./oToCAM.ko